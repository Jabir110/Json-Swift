//
//  ViewController.swift
//  SwiftSampleCode
//
//  Created by mackbook on 2/23/17.
//  Copyright © 2017 mackbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet var tblView: UITableView!
    
    var arrSampleCodeList:[String] = []

    
    override func viewDidLoad()
    {
        arrSampleCodeList += ["TableView","CollectionView","Form Validation"]
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - UITableViewDataSource
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return (self.arrSampleCodeList .count)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = (self.arrSampleCodeList [indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if indexPath.row == 0
        {
            let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "TableviewExampleVC") as! TableviewExampleVC
            self.navigationController?.pushViewController(secondViewController, animated: true)
        }
        if indexPath.row == 1
        {
            let CollectionViewExampleVC = self.storyboard?.instantiateViewController(withIdentifier: "CollectionViewExampleVC") as! CollectionViewExampleVC
            self.navigationController?.pushViewController(CollectionViewExampleVC, animated: true)
        }
        if indexPath.row == 2
        {
            let ValidationFormVC = self.storyboard?.instantiateViewController(withIdentifier: "ValidationFormVC") as! ValidationFormVC
            self.navigationController?.pushViewController(ValidationFormVC, animated: true)
        }
    }


}

