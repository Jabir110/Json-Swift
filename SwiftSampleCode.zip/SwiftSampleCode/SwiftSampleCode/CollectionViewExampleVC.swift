//
//  CollectionViewExampleVC.swift
//  SwiftSampleCode
//
//  Created by mackbook on 2/23/17.
//  Copyright © 2017 mackbook. All rights reserved.
//

import Alamofire
import Kingfisher
import Loader

import UIKit

class CollectionViewExampleVC: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {

    @IBOutlet var CollectionViewDemo: UICollectionView!
    
    var arrList = [AnyObject]()
    
    var loader: Loader?

    override func viewDidLoad()
    {
        super.viewDidLoad()

        self.title = "TableView AlamoFire"
        
        loader = Loader(container: self.view, colorOne: UIColor.red, colorTwo: UIColor.black)
        loader?.show()
        
        self.CollectionViewDemo.isHidden = true
        
        Alamofire.request("http://ohdeals.com/mobileapp/category_list.php").responseJSON
            {
                (responseData) -> Void in
                
                if((responseData.result.value) != nil)
                {
                    let json = responseData.result.value as! NSDictionary
                    
                    print("Dic Count: \((json.value(forKey: "data") as! NSArray) .count)")
                    
                    print("New Dic: \((json.value(forKey: "data") as! NSArray) [0] as! NSDictionary)")
                    
                    print("ID: \(((json.value(forKey: "data") as! NSArray) [0] as! NSDictionary) .value(forKey: "id") as! NSString)")
                    
                    print("category name: \(((json.value(forKey: "data") as! NSArray) [0] as! NSDictionary) .value(forKey: "category_name") as! NSString)")
                    
                    self.arrList = (json.value(forKey: "data") as! NSArray) as [AnyObject]
                    
                    print("ArrList: \(self.arrList)");
                    
                    self.CollectionViewDemo.reloadData()
                    
                    self.CollectionViewDemo.isHidden = false
                    
                    self.loader?.remove()
                    
                }
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return (self.arrList .count)

    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionCell
        
        let fruitName:String = ((self.arrList [indexPath.row] as! NSDictionary) .value(forKey: "category_name") as! NSString) as String
        
        let imageName:String = ((self.arrList [indexPath.row] as! NSDictionary) .value(forKey: "category_image") as! NSString) as String
        
        let url = URL(string: "http://ohdeals.com/mobileapp/images/\(imageName)")!
        
        print("Image URL:\(url)")
        
        cell.imgView?.kf.setImage(with: url, placeholder: nil, options: [.transition(ImageTransition.fade(1))], progressBlock: { (receivedSize, totalSize) in
            
            print("\(indexPath.row + 1): \(receivedSize)/\(totalSize)")
            
        }, completionHandler: { (image, error, cacheType, url) in
            print("\(indexPath.row + 1): Finished")
            
        })
        
        cell.lblName?.text = fruitName
        
        cell.viewMain.layer.shadowColor = UIColor.lightGray.cgColor
        cell.viewMain.layer.shadowOpacity = 0.3
        cell.viewMain.layer.shadowOffset = CGSize.zero
        cell.viewMain.layer.shadowRadius = 2
        
        cell.viewMain.layer.borderWidth = 1
        cell.viewMain.layer.borderColor = UIColor.lightGray.cgColor
        cell.viewMain.layer.cornerRadius = 2
        
        return cell

    }

}
