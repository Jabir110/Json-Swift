//
//  TableviewExampleVC.swift
//  SwiftSampleCode
//
//  Created by mackbook on 2/23/17.
//  Copyright © 2017 mackbook. All rights reserved.
//

import Alamofire
import Kingfisher
import Loader

import UIKit

class TableviewExampleVC: UIViewController,UITableViewDataSource, UITableViewDelegate {

    @IBOutlet var tblView: UITableView!
    
    var arrList = [AnyObject]()

    var json1 = [String:AnyObject]()
    
    var loader: Loader?

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.title = "TableView AlamoFire"
        
        loader = Loader(container: self.view, colorOne: UIColor.red, colorTwo: UIColor.black)
        loader?.show()
        
        self.tblView.isHidden = true
        
        Alamofire.request("http://ohdeals.com/mobileapp/category_list.php").responseJSON
            {
                (responseData) -> Void in
                
                if((responseData.result.value) != nil)
                {
                    self.json1 = responseData.result.value as! Dictionary
                    
                    print("json1: \(self.json1)");

                    let json = (responseData.result.value as! NSDictionary)
                    
                    print("Dic Count: \((json.value(forKey: "data") as! NSArray) .count)")
                    
                    print("New Dic: \((json.value(forKey: "data") as! NSArray) [0] as! NSDictionary)")
                    
                    print("ID: \(((json.value(forKey: "data") as! NSArray) [0] as! NSDictionary) .value(forKey: "id") as! NSString)")
                    
                    print("category name: \(((json.value(forKey: "data") as! NSArray) [0] as! NSDictionary) .value(forKey: "category_name") as! NSString)")
                    
                    self.arrList = (json.value(forKey: "data") as! NSArray) as [AnyObject]
                    
                    print("ArrList: \(self.arrList)");
                    
                    self.tblView.reloadData()
                    
                    self.tblView.isHidden = false

                    self.loader?.remove()
                }
            }
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - UITableViewDataSource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return (self.arrList .count)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableCell
        
        let fruitName:String = ((self.arrList [indexPath.row] as! NSDictionary) .value(forKey: "category_name") as! NSString) as String
        
        let imageName:String = ((self.arrList [indexPath.row] as! NSDictionary) .value(forKey: "category_image") as! NSString) as String
        
        let url = URL(string: "http://ohdeals.com/mobileapp/images/\(imageName)")!
        
        print("Image URL:\(url)")
        
        cell.imgView?.kf.setImage(with: url, placeholder: nil, options: [.transition(ImageTransition.fade(1))], progressBlock: { (receivedSize, totalSize) in
            
            print("\(indexPath.row + 1): \(receivedSize)/\(totalSize)")
            
        }, completionHandler: { (image, error, cacheType, url) in
            print("\(indexPath.row + 1): Finished")
            
        })
        
        cell.lblName?.text = fruitName
        
        return cell
    }
}
