//
//  CollectionCell.swift
//  SwiftSampleCode
//
//  Created by mackbook on 2/23/17.
//  Copyright © 2017 mackbook. All rights reserved.
//

import UIKit

class CollectionCell: UICollectionViewCell {
    
    @IBOutlet var viewMain: UIView!
    @IBOutlet var imgView: UIImageView!
    @IBOutlet var lblName: UILabel!

}
